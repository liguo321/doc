package com.d3sq.sns.vo;

import java.util.List;

public class BBSReplyVo {
	
	private List<RootReplyVo> reply;

	public List<RootReplyVo> getReply() {
		return reply;
	}

	public void setReply(List<RootReplyVo> reply) {
		this.reply = reply;
	}

	

}
