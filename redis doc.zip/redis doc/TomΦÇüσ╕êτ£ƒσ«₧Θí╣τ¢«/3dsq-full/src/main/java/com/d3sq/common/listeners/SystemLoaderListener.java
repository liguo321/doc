package com.d3sq.common.listeners;

import org.springframework.web.context.ContextLoaderListener;

/**
 * 系统初始化
 *
 */
public class SystemLoaderListener extends ContextLoaderListener{

	
}
