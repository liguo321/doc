package com.d3sq.explorer.service;

public interface IResourceService {

}
