package com.d3sq.search.service;

import javax.core.common.ResultMsg;

public interface IResidentialService {

	public ResultMsg<?> getById(Long id);
}
