package com.d3sq.sns.vo;

public class ImageVo {
	
	private String imgUrl;
	private String code;
	private String litimg;
	private Integer width;
	private Integer height;
	private Integer litWidth;
	private Integer litHeight;

	public String getImgUrl() {
		
		return imgUrl;
	}

	public void setImgUrl(String imgUrl) {
		
		this.imgUrl = imgUrl;
	}

	public String getLitimg() {
		return litimg;
	}

	public void setLitimg(String litimg) {
		this.litimg = litimg;
	}

	public Integer getWidth() {
		return width;
	}

	public void setWidth(Integer width) {
		this.width = width;
	}

	public Integer getHeight() {
		return height;
	}

	public void setHeight(Integer height) {
		this.height = height;
	}

	public Integer getLitWidth() {
		return litWidth;
	}

	public void setLitWidth(Integer litWidth) {
		this.litWidth = litWidth;
	}

	public Integer getLitHeight() {
		return litHeight;
	}

	public void setLitHeight(Integer litHeight) {
		this.litHeight = litHeight;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
}
