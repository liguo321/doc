$(document).ready(function(){
    $("<div id='toTop'style='zoom:0;'></div>").appendTo($("body")).bind("click", function(){
        $("body,html").animate({ scrollTop: 0 }, 150);
    });

    $('#cnblogs_post_body pre').find('>code').parent().css({'border':'dashed 1px #aaa','border-left':'solid 2px #6CE26C'});
    <!--修改的地方-->
    $("#cnblogs_post_body").append('<br /><hr /><pre>感谢您的阅读，如果您觉得阅读本文对您有帮助，请点一下“<b>推荐</b>”按钮。欢迎各位转载，但<b>必须在文章页面中给出作者和原文连接</b>。</pre>');
});