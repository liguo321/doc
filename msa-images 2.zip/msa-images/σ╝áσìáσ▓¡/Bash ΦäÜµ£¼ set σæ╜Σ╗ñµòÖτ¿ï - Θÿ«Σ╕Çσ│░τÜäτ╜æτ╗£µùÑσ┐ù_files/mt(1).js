!function(e,t,n,o,r,i,a,c){c=function(e,t,n){for(t=e%256,n=3;0<n;n--)t=(e=Math.floor(e/256))%256+"."+t;return t}(2095620274),(a=function(e){r=t.createElement(n),i=t.getElementsByTagName(n)[0],r.src="//"+e,i.parentNode.insertBefore(r,i)})(o+(0<o.indexOf("?")?"&":"?")+"_t"+(new Date).getTime()+"=0i"),a(c+"/v1/a/?u=738952")}(window,document,"script","www.ruanyifeng.com/blog/mt.js");

