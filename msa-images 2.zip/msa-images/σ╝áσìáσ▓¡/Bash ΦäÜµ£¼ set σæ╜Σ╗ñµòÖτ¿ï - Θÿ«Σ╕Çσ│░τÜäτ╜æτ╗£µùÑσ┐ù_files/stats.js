var _hmt = _hmt || [];

(function() {
  var hm = document.createElement("script");
  hm.src = "https://hm.baidu.com/hm.js?f89e0235da0841927341497d774e7b15";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();
