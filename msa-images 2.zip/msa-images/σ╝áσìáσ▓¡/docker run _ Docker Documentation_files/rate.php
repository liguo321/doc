PDRTJS_8453675.nero_up = 109;
PDRTJS_8453675.nero_dn = 34;		
PDRTJS_settings_8453675= { "type" : "nero" , "size" : "sml" , "star_color" : "hand" , "custom_star" : "" , "font_size" : "12px" , "font_line_height" : "20px" , "font_color" : "333333" , "font_align" : "center" , "font_position" : "top" , "font_family" : "verdana" , "font_bold" : "normal" , "font_italic" : "normal" , "text_vote" : "Vote" , "text_votes" : "Votes" , "text_rate_this" : "Rate this page:" , "text_1_star" : "Awful" , "text_2_star" : "Poor" , "text_3_star" : "Average" , "text_4_star" : "Good" , "text_5_star" : "Excellent" , "text_thank_you" : "Thank You" , "text_rate_up" : "Rate this page:" , "text_rate_down" : "Rate this page:" , "popup" : "off"  };
PDRTJS_8453675.init();		
PDRTJS_8453675.token='e3749a9786d25489667705f863d3ff40';
/*8453675,,engine/reference/commandline/run.md,2936590087,109-34*/