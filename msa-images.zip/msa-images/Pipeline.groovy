@Library('common-library') _   //引用一个外部类型

pipeline {
    agent any       // 声明全局分发节点

    environment {   // 声明全局变量
        imageName = "svt/test"
        serviceName = "svt-test"
    }

    stages {    // 定义构建的步骤
        stage('CI') {  // 步骤1，名称为CI，自定义即可
            agent { label 'build' }  // 指定一个分发节点
            steps {     // CI步骤里的具体动作
                cleanWs()
                gitScm("${repoUrl}","${branch}","${credentialsId}")  // 从git上拉一个代码下到build节点

                // 把这个项目在docker提供的aspnetcore镜像里运行
                dir("${deployPath}") {
                    sh "docker run --rm --tty --user root -v ${WORKSPACE}/:/src/ --workdir=/src/deploy/ microsoft/dotnet sh publish.sh"
                    buildImage("${imageName}")
                }
            }
        }

        stage('ServiceRun') {
            agent { label 'svt' }
            steps {
                startService("${serviceName}", "${imageName}")  // 启动服务
            }
        }
    }

}

