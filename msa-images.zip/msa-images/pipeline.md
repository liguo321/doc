# 扩展共享库

* 代码复用

* 版本控制

* 安全控制

  SCM插件（git）

  系统管理 -> 系统配置 -> 全局Pipeline库

  extend-pipeline

```properties

jenkinsfile
	jenkins-demo.jenkinfile
dockerfile
	jenkins-demo.dockerfile
src                             # Groovy 资源文件。执行Pipeline时，该目录将添加到类路径中
	com
		lens
			Hello.groovy    	# com.lens.java.Hello.class
vars                            # Pipeline访问的全局变量的脚本
	servicePipeline.groovy  	# 程序入口
	gitCheckout.groovy      	# 负责迁出项目源码
	mvnPackage.groovy       	# 负责编译打包
	dockerImageBuild.groovy 	# 负责构建项目镜像
	dockerServiceStart.groovy   # 负责将镜像推到仓库
	dockerServiceStart.groovy   # 负责启动docker服务
	dockerServiceStart.txt		# 帮助文档,HTML,Markdown格式化
resources						# 外部库加载关联的非Groovy文件(内部库暂不支持)
	com
		lens
			hello.json
	
```

* Jenkinsfile

  ```groovy
  @Library('extend-pipeline@master') _
  
  @Library(['extend-pipeline@master', 'common-pipeline@master']) _
  
  properties([parameters([string(name: 'LIB_VERSION', defaultValue: 'master')])])
  library "extend-pipeline@${params.LIB_VERSION}"
  
  无预定义库
  library identifier: 'extend-pipeline@master', retriever: modernSCM(
    [$class: 'GitSCMSource',
     remote: 'git URL',
     credentialsId: 'my-private-key'])
  ```





  扩展共享库 中建  Jenkinsfile、Dockerfile

  - 搭建jenkins环境，安装插件
  - 建立pipeline公用类库，文件夹vars，默认的
  - 添加.groovy文件，可以由以下几个类库组成
    - dockerImageBuild 负责构建项目镜像
    - dockerImageDeploy 负责将镜像推到仓库
    - dockerServiceStart 负责启动docker服务
    - gitCheckout 负责迁出项目源码
    - servicePipeline 程序入口
  - 根据项目添加对应的.jenkinsfile文件
  - jenkins里建立**文件夹**，选择公用类库的仓库，起个名字
  - 在文件夹里建立新的Job，然后选择对象的jenkinsfile文件 jenkins-demo.jenkinfile
  - 项目构建完成 

  Jenkinsfile/jenkins-demo.jenkinfile

  ```groovy
  @Library("extend-pipeline") _
  
  servicePipeline ( {
     repoUrl = "git@github.com:bfyxzls/LindDotNetCore.git"
     credentialsId = "012f0d4e-47e2-48ce-8b9e-cd399e9b3d61"
     branches = "dev"
   })
  ```

​       

​       Dockerfile/jenkins-demo.dockerfile





* servicePipeline.groovy

  ```groovy
  def call(body) {
      def config = [:]
      body.resolveStrategy = Closure.DELEGATE_FIRST
      body.delegate = config
      body()
  
      pipeline {
          agent { label 'build-server' }
         
          stages {
              stage('Initialization') {
                  steps {
                      script {
                         echo "项目初始化"
                      }
                  }
              }
              stage('CI') {
                  steps{
                      script{
                          gitCheckout{
                              repoUrl = config.repoUrl
                              credentialsId = config.credentialsId
                              branches = config.branches
                              commit = config.commit
                          }
                      }
                  }
              }
              stage('Service') {
              echo "启动dockder服务"
            }
          }
      }
  }
  ```

* gitCheckout

  ```groovy
  def call(body) {
      def config = [:]
      body.resolveStrategy = Closure.DELEGATE_FIRST
      body.delegate = config
      body()
  
      echo 'Checking out code from "' + config.repoUrl + '" with credentialsId "' + \
          config.credentialsId + '" ...'
      
      checkout([$class: 'GitSCM', branches: [[name: config.branches]], 
      doGenerateSubmoduleConfigurations: false, 
      extensions: [], 
      submoduleCfg: [], 
      userRemoteConfigs: [[credentialsId: config.credentialsId, url: config.repoUrl]]])   
  }
  ```
