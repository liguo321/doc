var collectionsTOC = new Array()
collectionsTOC["library"] = [
  
  {
  "path":"/samples/library/adminer/",
  "title":"adminer"
  },
  
  {
  "path":"/samples/library/aerospike/",
  "title":"aerospike"
  },
  
  {
  "path":"/samples/library/alpine/",
  "title":"alpine"
  },
  
  {
  "path":"/samples/library/alt/",
  "title":"alt"
  },
  
  {
  "path":"/samples/library/amazonlinux/",
  "title":"amazonlinux"
  },
  
  {
  "path":"/samples/library/arangodb/",
  "title":"arangodb"
  },
  
  {
  "path":"/samples/library/backdrop/",
  "title":"backdrop"
  },
  
  {
  "path":"/samples/library/bash/",
  "title":"bash"
  },
  
  {
  "path":"/samples/library/bonita/",
  "title":"bonita"
  },
  
  {
  "path":"/samples/library/buildpack-deps/",
  "title":"buildpack-deps"
  },
  
  {
  "path":"/samples/library/busybox/",
  "title":"busybox"
  },
  
  {
  "path":"/samples/library/cassandra/",
  "title":"cassandra"
  },
  
  {
  "path":"/samples/library/centos/",
  "title":"centos"
  },
  
  {
  "path":"/samples/library/chronograf/",
  "title":"chronograf"
  },
  
  {
  "path":"/samples/library/cirros/",
  "title":"cirros"
  },
  
  {
  "path":"/samples/library/clearlinux/",
  "title":"clearlinux"
  },
  
  {
  "path":"/samples/library/clefos/",
  "title":"clefos"
  },
  
  {
  "path":"/samples/library/clojure/",
  "title":"clojure"
  },
  
  {
  "path":"/samples/library/composer/",
  "title":"composer"
  },
  
  {
  "path":"/samples/library/consul/",
  "title":"consul"
  },
  
  {
  "path":"/samples/library/convertigo/",
  "title":"convertigo"
  },
  
  {
  "path":"/samples/library/couchbase/",
  "title":"couchbase"
  },
  
  {
  "path":"/samples/library/couchdb/",
  "title":"couchdb"
  },
  
  {
  "path":"/samples/library/crate/",
  "title":"crate"
  },
  
  {
  "path":"/samples/library/crux/",
  "title":"crux"
  },
  
  {
  "path":"/samples/library/debian/",
  "title":"debian"
  },
  
  {
  "path":"/samples/library/docker/",
  "title":"docker"
  },
  
  {
  "path":"/samples/library/drupal/",
  "title":"drupal"
  },
  
  {
  "path":"/samples/library/eclipse-mosquitto/",
  "title":"eclipse-mosquitto"
  },
  
  {
  "path":"/samples/library/eggdrop/",
  "title":"eggdrop"
  },
  
  {
  "path":"/samples/library/elasticsearch/",
  "title":"elasticsearch"
  },
  
  {
  "path":"/samples/library/elixir/",
  "title":"elixir"
  },
  
  {
  "path":"/samples/library/erlang/",
  "title":"erlang"
  },
  
  {
  "path":"/samples/library/euleros/",
  "title":"euleros"
  },
  
  {
  "path":"/samples/library/fedora/",
  "title":"fedora"
  },
  
  {
  "path":"/samples/library/flink/",
  "title":"flink"
  },
  
  {
  "path":"/samples/library/fsharp/",
  "title":"fsharp"
  },
  
  {
  "path":"/samples/library/gazebo/",
  "title":"gazebo"
  },
  
  {
  "path":"/samples/library/gcc/",
  "title":"gcc"
  },
  
  {
  "path":"/samples/library/geonetwork/",
  "title":"geonetwork"
  },
  
  {
  "path":"/samples/library/ghost/",
  "title":"ghost"
  },
  
  {
  "path":"/samples/library/golang/",
  "title":"golang"
  },
  
  {
  "path":"/samples/library/gradle/",
  "title":"gradle"
  },
  
  {
  "path":"/samples/library/groovy/",
  "title":"groovy"
  },
  
  {
  "path":"/samples/library/haproxy/",
  "title":"haproxy"
  },
  
  {
  "path":"/samples/library/haskell/",
  "title":"haskell"
  },
  
  {
  "path":"/samples/library/haxe/",
  "title":"haxe"
  },
  
  {
  "path":"/samples/library/hello-seattle/",
  "title":"hello-seattle"
  },
  
  {
  "path":"/samples/library/hello-world/",
  "title":"hello-world"
  },
  
  {
  "path":"/samples/library/hola-mundo/",
  "title":"hola-mundo"
  },
  
  {
  "path":"/samples/library/httpd/",
  "title":"httpd"
  },
  
  {
  "path":"/samples/library/hylang/",
  "title":"hylang"
  },
  
  {
  "path":"/samples/library/ibmjava/",
  "title":"ibmjava"
  },
  
  {
  "path":"/samples/library/influxdb/",
  "title":"influxdb"
  },
  
  {
  "path":"/samples/library/irssi/",
  "title":"irssi"
  },
  
  {
  "path":"/samples/library/jetty/",
  "title":"jetty"
  },
  
  {
  "path":"/samples/library/joomla/",
  "title":"joomla"
  },
  
  {
  "path":"/samples/library/jruby/",
  "title":"jruby"
  },
  
  {
  "path":"/samples/library/julia/",
  "title":"julia"
  },
  
  {
  "path":"/samples/library/kaazing-gateway/",
  "title":"kaazing-gateway"
  },
  
  {
  "path":"/samples/library/kapacitor/",
  "title":"kapacitor"
  },
  
  {
  "path":"/samples/library/kibana/",
  "title":"kibana"
  },
  
  {
  "path":"/samples/library/known/",
  "title":"known"
  },
  
  {
  "path":"/samples/library/kong/",
  "title":"kong"
  },
  
  {
  "path":"/samples/library/lightstreamer/",
  "title":"lightstreamer"
  },
  
  {
  "path":"/samples/library/logstash/",
  "title":"logstash"
  },
  
  {
  "path":"/samples/library/mageia/",
  "title":"mageia"
  },
  
  {
  "path":"/samples/library/mariadb/",
  "title":"mariadb"
  },
  
  {
  "path":"/samples/library/matomo/",
  "title":"matomo"
  },
  
  {
  "path":"/samples/library/maven/",
  "title":"maven"
  },
  
  {
  "path":"/samples/library/mediawiki/",
  "title":"mediawiki"
  },
  
  {
  "path":"/samples/library/memcached/",
  "title":"memcached"
  },
  
  {
  "path":"/samples/library/mongo-express/",
  "title":"mongo-express"
  },
  
  {
  "path":"/samples/library/mongo/",
  "title":"mongo"
  },
  
  {
  "path":"/samples/library/mono/",
  "title":"mono"
  },
  
  {
  "path":"/samples/library/mysql/",
  "title":"mysql"
  },
  
  {
  "path":"/samples/library/nats-streaming/",
  "title":"nats-streaming"
  },
  
  {
  "path":"/samples/library/nats/",
  "title":"nats"
  },
  
  {
  "path":"/samples/library/neo4j/",
  "title":"neo4j"
  },
  
  {
  "path":"/samples/library/neurodebian/",
  "title":"neurodebian"
  },
  
  {
  "path":"/samples/library/nextcloud/",
  "title":"nextcloud"
  },
  
  {
  "path":"/samples/library/nginx/",
  "title":"nginx"
  },
  
  {
  "path":"/samples/library/node/",
  "title":"node"
  },
  
  {
  "path":"/samples/library/notary/",
  "title":"notary"
  },
  
  {
  "path":"/samples/library/nuxeo/",
  "title":"nuxeo"
  },
  
  {
  "path":"/samples/library/odoo/",
  "title":"odoo"
  },
  
  {
  "path":"/samples/library/open-liberty/",
  "title":"open-liberty"
  },
  
  {
  "path":"/samples/library/openjdk/",
  "title":"openjdk"
  },
  
  {
  "path":"/samples/library/opensuse/",
  "title":"opensuse"
  },
  
  {
  "path":"/samples/library/oraclelinux/",
  "title":"oraclelinux"
  },
  
  {
  "path":"/samples/library/orientdb/",
  "title":"orientdb"
  },
  
  {
  "path":"/samples/library/owncloud/",
  "title":"owncloud"
  },
  
  {
  "path":"/samples/library/percona/",
  "title":"percona"
  },
  
  {
  "path":"/samples/library/perl/",
  "title":"perl"
  },
  
  {
  "path":"/samples/library/photon/",
  "title":"photon"
  },
  
  {
  "path":"/samples/library/php-zendserver/",
  "title":"php-zendserver"
  },
  
  {
  "path":"/samples/library/php/",
  "title":"php"
  },
  
  {
  "path":"/samples/library/piwik/",
  "title":"piwik"
  },
  
  {
  "path":"/samples/library/plone/",
  "title":"plone"
  },
  
  {
  "path":"/samples/library/postgres/",
  "title":"postgres"
  },
  
  {
  "path":"/samples/library/pypy/",
  "title":"pypy"
  },
  
  {
  "path":"/samples/library/python/",
  "title":"python"
  },
  
  {
  "path":"/samples/library/r-base/",
  "title":"r-base"
  },
  
  {
  "path":"/samples/library/rabbitmq/",
  "title":"rabbitmq"
  },
  
  {
  "path":"/samples/library/rakudo-star/",
  "title":"rakudo-star"
  },
  
  {
  "path":"/samples/library/rapidoid/",
  "title":"rapidoid"
  },
  
  {
  "path":"/samples/library/redis/",
  "title":"redis"
  },
  
  {
  "path":"/samples/library/redmine/",
  "title":"redmine"
  },
  
  {
  "path":"/samples/library/registry/",
  "title":"registry"
  },
  
  {
  "path":"/samples/library/rethinkdb/",
  "title":"rethinkdb"
  },
  
  {
  "path":"/samples/library/rocket.chat/",
  "title":"rocket.chat"
  },
  
  {
  "path":"/samples/library/ros/",
  "title":"ros"
  },
  
  {
  "path":"/samples/library/ruby/",
  "title":"ruby"
  },
  
  {
  "path":"/samples/library/rust/",
  "title":"rust"
  },
  
  {
  "path":"/samples/library/scratch/",
  "title":"scratch"
  },
  
  {
  "path":"/samples/library/sentry/",
  "title":"sentry"
  },
  
  {
  "path":"/samples/library/silverpeas/",
  "title":"silverpeas"
  },
  
  {
  "path":"/samples/library/sl/",
  "title":"sl"
  },
  
  {
  "path":"/samples/library/solr/",
  "title":"solr"
  },
  
  {
  "path":"/samples/library/sonarqube/",
  "title":"sonarqube"
  },
  
  {
  "path":"/samples/library/sourcemage/",
  "title":"sourcemage"
  },
  
  {
  "path":"/samples/library/spiped/",
  "title":"spiped"
  },
  
  {
  "path":"/samples/library/storm/",
  "title":"storm"
  },
  
  {
  "path":"/samples/library/swarm/",
  "title":"swarm"
  },
  
  {
  "path":"/samples/library/swift/",
  "title":"swift"
  },
  
  {
  "path":"/samples/library/swipl/",
  "title":"swipl"
  },
  
  {
  "path":"/samples/library/teamspeak/",
  "title":"teamspeak"
  },
  
  {
  "path":"/samples/library/telegraf/",
  "title":"telegraf"
  },
  
  {
  "path":"/samples/library/thrift/",
  "title":"thrift"
  },
  
  {
  "path":"/samples/library/tomcat/",
  "title":"tomcat"
  },
  
  {
  "path":"/samples/library/tomee/",
  "title":"tomee"
  },
  
  {
  "path":"/samples/library/traefik/",
  "title":"traefik"
  },
  
  {
  "path":"/samples/library/ubuntu/",
  "title":"ubuntu"
  },
  
  {
  "path":"/samples/library/vault/",
  "title":"vault"
  },
  
  {
  "path":"/samples/library/websphere-liberty/",
  "title":"websphere-liberty"
  },
  
  {
  "path":"/samples/library/wordpress/",
  "title":"wordpress"
  },
  
  {
  "path":"/samples/library/xwiki/",
  "title":"xwiki"
  },
  
  {
  "path":"/samples/library/yourls/",
  "title":"yourls"
  },
  
  {
  "path":"/samples/library/znc/",
  "title":"znc"
  },
  
  {
  "path":"/samples/library/zookeeper/",
  "title":"zookeeper"
  }
  
]
