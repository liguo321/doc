#!/bin/bash || #!/bin/sh
set -euxo pipefail
# $ bash -euxo pipefail script.sh
# e：异常退出
# u: 变量不存在报错退出
# x：运行结果前输出执行的命令
# o pipefail：只要一个子命令失败，整个管道命令就失败退出 foo | echo a



build.sh "Prod"

--- build.sh
set -ex
export IMAGE_NAME=
export Registry_Url=
docker build --no-cache --pull -t $IMAGE_NAME -build-arg source=$1 ./

docker tag $IMAGE_NAME $Registry_Url/$IMAGE_NAME
docker push $Registry_Url/$IMAGE_NAME

---Dockerfile
FROM microsoft/aspnetcore:2.0
ARG source
run echo $source
COPY sources.list /etc/apt/sources.list
RUN /bin/cp /usr/share/zoneinfo/Asia/Shanghai /etc/localtime && echo 'Asia/Shanghai' >/etc/timezone
RUN apt-get update && apt-get -y install libgdiplus && apt-get clean
ENV ASPNETCORE_ENVIRONMENT=$source
WORKDIR /app
EXPOSE 80
COPY obj/Docker/publish .
ENTRYPOINT ["dotnet", "Validate.dll"]


