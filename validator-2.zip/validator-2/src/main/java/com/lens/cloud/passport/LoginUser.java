package com.lens.cloud.passport;

public class LoginUser {

	// ILoginService.common方法参数,顺序一致
	private String username;
	private String password;

	// ILoginService.qq方法参数
	private String openId;

	// ILoginService.telphone方法参数
	private String telphone;
	private String code;

	public LoginUser() {
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getOpenId() {
		return openId;
	}

	public void setOpenId(String openId) {
		this.openId = openId;
	}

	public String getTelphone() {
		return telphone;
	}

	public void setTelphone(String telphone) {
		this.telphone = telphone;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
}
