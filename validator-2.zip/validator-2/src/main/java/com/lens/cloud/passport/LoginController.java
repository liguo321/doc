package com.lens.cloud.passport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

@RestController
public class LoginController {


	@Autowired
	ILoginService loginService;

	/**
	 *
	 * @param loginUser 当前登录类型的参数不为空，其它为空
	 * @param loginType 同ILoginService方法名，common、qq、telphone
	 * @return
	 * @throws NoSuchMethodException
	 * @throws InvocationTargetException
	 * @throws IllegalAccessException
	 */
	@PostMapping("/login")
	public Object login(@RequestBody LoginUser loginUser, @RequestParam String loginType) throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
		List<Object> args = getNotNullParam(loginUser);
		Method method = loginService.getClass().getDeclaredMethod(loginType, getNotNullParamClass(args).toArray(new Class[args.size()]));
		return method.invoke(loginService, args.toArray());
	}

	public List<Object> getNotNullParam(LoginUser loginUser) throws IllegalAccessException {
		List<Object> notNullParam = new ArrayList<>();
		Field[] fields = loginUser.getClass().getDeclaredFields();
		for (Field f : fields) {
			f.setAccessible(true);
			Object paramValue = f.get(loginUser);
			if (paramValue != null) {
				notNullParam.add(paramValue);
			}
		}
		return notNullParam;
	}

	public List<Class> getNotNullParamClass(List<Object> args) {
		List<Class> notNullParamClass = new ArrayList<>();
		args.forEach(arg -> notNullParamClass.add(arg.getClass()));
		return notNullParamClass;
	}
}
