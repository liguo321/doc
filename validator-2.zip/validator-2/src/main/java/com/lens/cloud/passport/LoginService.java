package com.lens.cloud.passport;

import org.springframework.stereotype.Service;

@Service
public class LoginService implements ILoginService {

	@Override
	public String common(String username, String password) {
		return "common:" + username + "|" + password;
	}

	@Override
	public String qq(String openId) {
		return "qq:" + openId;
	}

	@Override
	public String telphone(String telphone,String code) {
		return "telphone:" + telphone + ":" + code;
	}
}
