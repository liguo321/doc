package com.lens.cloud.passport;

public interface ILoginService {
	String common(String username, String password);

	String qq(String openId);

	String telphone(String telphone,String code);
}
