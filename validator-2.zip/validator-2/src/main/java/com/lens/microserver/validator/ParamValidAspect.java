package com.lens.microserver.validator;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.validation.Validator;
import java.util.Set;

@Aspect
@Component
public class ParamValidAspect {
	private static final Logger log = LoggerFactory.getLogger(ParamValidAspect.class);

	@Autowired
	private Validator validator;

	//@Before("@annotation(paramValid)")
	//public void paramValidCheck(JoinPoint point, ParamValid paramValid) {
	//	Class[] validateClass = paramValid.value();
	//	if (validateClass.length > 0) {
	//		int size = validateClass.length;
	//		Object[] paramObj = point.getArgs();
	//		for (int i = 0; i < size; i++) {
	//			if (paramObj[i].getClass() == validateClass[i]) {
	//				Set<ConstraintViolation<Object>> validate = validator.validate(paramObj[i]);
	//				if (validate.size() > 0) {
	//					throw new ConstraintViolationException("bean validate error", validate);
	//				}
	//			}
	//		}
	//	}
	//}


	@Before("@annotation(paramValid)")
	public void paramValid(JoinPoint point, ParamValid paramValid) {
		validateBeans(point, paramValid.value());
		validateParameters(point);
	}

	private void validateBeans(JoinPoint point, Class[] validateClass) {
		if (validateClass.length > 0) {
			int size = validateClass.length;
			Object[] paramObj = point.getArgs();
			for (int i = 0; i < size; i++) {
				if (paramObj[i].getClass() == validateClass[i]) {
					Set<ConstraintViolation<Object>> validate = validator.validate(paramObj[i]);
					if (validate.size() > 0) {
						throw new ConstraintViolationException("bean validate error", validate);
					}
				}
			}
		}
	}

	private void validateParameters(JoinPoint point) {
		Set<ConstraintViolation<Object>> validate = validator.forExecutables().validateParameters(point.getTarget(),
				((MethodSignature) point.getSignature()).getMethod(),
				point.getArgs(), new Class<?>[0]);
		if (validate.size() > 0) {
			throw new ConstraintViolationException("param validate error", validate);
		}
	}

}


