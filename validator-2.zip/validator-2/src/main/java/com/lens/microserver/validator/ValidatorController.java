package com.lens.microserver.validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.Validator;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;

@RestController
public class ValidatorController {

    @Autowired
    private Validator validator;

    @PostMapping("/bean")
    public String bean(@RequestBody @Valid User user, BindingResult result) {
        return "bean OK";
    }

    @GetMapping("/param")
    public String param(
            @Email
            @NotBlank(message = "用户名不能为空")
            @RequestParam(name = "userName")
                    String userName,
            @NotBlank(message = "性别不能为空")
            @RequestParam(name = "sex")
                    String sex) {
        return "param OK:";
    }

    //@ParamValid({User.class, String.class})
    //@PostMapping("/check")
    //public String check(@RequestBody User user, @Email @NotBlank(message = "密码不能为空") @RequestParam String password) {
    //    return "ok";
    //}

    @ParamValid({ User.class })
    @PostMapping("/check")
    public String check(@RequestBody User user, @NotBlank(message = "密码error不能为空") @RequestParam String password) {
        return "ok";
    }
}


// 标记注解 check 切面类 ? 参数顺序，前面的验证参数顺序对应ParamValid中的类
// https://cloud.tencent.com/developer/article/1054194
// https://juejin.im/post/5a5e1159518825732b19d8ce

// ** https://my.oschina.net/u/3211616/blog/821343