package com.lens.microserver.validator;

import java.lang.annotation.*;

/**
 * 参数校验类
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface ParamValid {
	/**
	 * 方法中的需要验证的参数必须与此一一顺序对应。即验证的参数在前
	 * @return 参数类型数组(class)
	 */
	Class<?>[] value() default {};
}