package com.lens.microserver.validator;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;

public class User {
    @Email
    @NotBlank(message = "用户名不能为空")
    private String userName;

    @NotBlank(message = "性别不能为空")
    private String sex;

    public User() {
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }
}
