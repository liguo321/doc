package com.lens.microserver.validator;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.validation.ValidationException;

@ControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler
	@ResponseBody
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	public String handle(ValidationException exception) {
		if (exception instanceof ConstraintViolationException) {
			ConstraintViolationException ex = (ConstraintViolationException)exception;
			System.out.println(ex.getMessage());
			StringBuffer buffer = new StringBuffer();
			for (ConstraintViolation item : ex.getConstraintViolations()) {
				buffer.append(item.getMessage()).append(".");
			}
			return buffer.toString();
		}
		return "bas request";
	}
}
