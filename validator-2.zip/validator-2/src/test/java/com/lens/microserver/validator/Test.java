package com.lens.microserver.validator;

public class Test {
	public static void main(String[] args) {
		Object aa = new String("aaaa");

		System.out.println(aa.getClass());
	}
}
